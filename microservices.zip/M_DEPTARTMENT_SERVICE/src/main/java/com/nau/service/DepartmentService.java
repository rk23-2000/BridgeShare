package com.nau.service;

import java.util.List;

import com.nau.entities.DepartmentEntity;

public interface DepartmentService {
	
	DepartmentEntity create(DepartmentEntity departmentEntity);
	DepartmentEntity getOne(Integer deptId);
	List<DepartmentEntity> getAll();

}
