package com.nau.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nau.entities.DepartmentEntity;
import com.nau.repository.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService{
	
	@Autowired
	private DepartmentRepository departmentRepository;

	@Override
	public DepartmentEntity create(DepartmentEntity departmentEntity) {
		return departmentRepository.save(departmentEntity);
	}

	@Override
	public DepartmentEntity getOne(Integer deptId) {
		return departmentRepository.findById(deptId).orElseThrow(()-> new RuntimeException("No Department found with id "+ deptId));
	}

	@Override
	public List<DepartmentEntity> getAll() {
		return departmentRepository.findAll();
	}

}
