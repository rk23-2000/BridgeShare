package com.nau.service;

import java.util.List;

import com.nau.entity.EmployeeEntity;
import com.nau.vo.EmployeeDepartmentVO;

public interface EmployeeService {
	
	public EmployeeEntity createEmployee(EmployeeEntity employeeEntity);
	public List<EmployeeEntity> getAll();
	public EmployeeEntity getOne(Integer empId);
	public List<EmployeeEntity> getByDeptId(Integer deptId); 
	public EmployeeDepartmentVO getEmployeeWithDepartmentInfo(Integer empId);
	EmployeeDepartmentVO getEmployeeWithDepartmentInfoWithFeign(Integer empId);
}
