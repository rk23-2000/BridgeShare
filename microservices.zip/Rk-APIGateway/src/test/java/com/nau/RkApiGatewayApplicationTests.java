package com.nau;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RkApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
