package com.rk.StudentApp.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rk.StudentApp.entity.StudentEntity;
import java.util.List;


@Repository
public interface StudentRepository extends JpaRepository<StudentEntity, Integer> {

	List<StudentEntity> findByLname(String lname);
}
