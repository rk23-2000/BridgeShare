package com.rk.StudentApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rk.StudentApp.entity.StudentEntity;

@Service
public class StudentService {

	@Autowired
	private StudentRepository repository;
	
	public Optional<StudentEntity> getbyId(Integer id) {
		return repository.findById(id);
	}
	
	public List<StudentEntity> getbyLname(String lname) {
		return repository.findByLname(lname);
	}
	
	public StudentEntity addStudent(StudentEntity entity) {
		return repository.save(entity);
	}
	public List<StudentEntity> getAll() {
		return repository.findAll();
	}
}
