package com.rk.StudentApp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rk.StudentApp.entity.StudentEntity;
import com.rk.StudentApp.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService studentService;

	@GetMapping("/getall")
	public List<StudentEntity> getAll() {
		return studentService.getAll();
	}

	@PostMapping("/saveStudent")
	public String addStudent(@RequestBody StudentEntity entity) {
		studentService.addStudent(entity);
		return "Record is saved: "+entity.getFname()+" "+entity.getLname();
	}
	@GetMapping("/getbyid/{id}")
	public Optional<StudentEntity> getbyId(@PathVariable("id") Integer id) {
		return studentService.getbyId(id);
	}
	@GetMapping("/getbylname/{lname}")
	public List<StudentEntity> getbyLname(@PathVariable("lname") String lname) {
		return studentService.getbyLname(lname);
	}
}
